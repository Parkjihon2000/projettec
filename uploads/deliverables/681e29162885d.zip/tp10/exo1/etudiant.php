<?php
require_once('connexion.php');
$db=new database();
$db->connect();
require_once('user.php');

class etudiant extends Utilisateur{
    private string $code_massar;
    private string $filiere; 
    private float $note;
    public function __construct(?string $id, string $nom, string $prenom, string $email, string $code, string $filiere, float $note) {
        parent::__construct($id ?? '', $nom, $email, 'etudiant'); // Pass an empty string if id is null
        $this->code_massar = $code;
        $this->filiere = $filiere;
        $this->note = $note;
    }

    // Getters
    public function getCodeMassar(): string {
        return $this->code_massar;
    }

    public function getFiliere(): string {
        return $this->filiere;
    }

    public function getNote(): float {
        return $this->note;
    }

    // Setters
    public function setCodeMassar(string $code_massar): void {
        $this->code_massar = $code_massar;
    }

    public function setFiliere(string $filiere): void {
        $this->filiere = $filiere;
    }

    public function setNote(float $note): void {
        $this->note = $note;
    }
    public function afficherProfil():void{
        Utilisateur::afficherProfil();
        echo "<div> Massar: " . $this->code_massar . " Filiére: " . $this->filiere . " Note: " . $this->note . "</div>";
    }
    


}