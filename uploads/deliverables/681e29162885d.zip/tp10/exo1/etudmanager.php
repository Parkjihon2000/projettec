<?php
require_once('connexion.php');
$db = new database();
$db->connect();
require_once('etudiant.php');

class manager extends etudiant {
    public function getAll(database $db): array {
        $sql = 'SELECT u.nom, u.prenom, u.email, s.codemassar, s.filiere, s.note 
                FROM users u 
                JOIN students s ON u.id = s.user_id 
                WHERE u.role = :role';
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':role', $role = 'etudiant');
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function ajouter(etudiant $e, database $db) {
        $nom = $e->getNom();
        $prenom = $e->getPrenom();
        $email = $e->getEmail();
        $code = $e->getCodeMassar();
        $filiere = $e->getFiliere();
        $note = $e->getNote();

        // Insert into `users` table
        $sqlUser = 'INSERT INTO users (nom, prenom, email, role) VALUES (:nom, :prenom, :email, "etudiant")';
        $stmtUser = $db->prepare($sqlUser);
        $stmtUser->bindParam(':nom', $nom);
        $stmtUser->bindParam(':prenom', $prenom);
        $stmtUser->bindParam(':email', $email);
        $stmtUser->execute();

        // Get the last inserted user ID
        $userId = $db->lastInsertId();

        // Insert into `students` table
        $sqlStudent = 'INSERT INTO students (user_id, codemassar, filiere, note) VALUES (:user_id, :codemassar, :filiere, :note)';
        $stmtStudent = $db->prepare($sqlStudent);
        $stmtStudent->bindParam(':user_id', $userId);
        $stmtStudent->bindParam(':codemassar', $code);
        $stmtStudent->bindParam(':filiere', $filiere);
        $stmtStudent->bindParam(':note', $note);
        $stmtStudent->execute();
    }

    public function rechercherParFiliere(database $db, string $filiere): array {
        $sql = 'SELECT u.nom, u.prenom, u.email, s.codemassar, s.filiere, s.note 
                FROM users u 
                JOIN students s ON u.id = s.user_id 
                WHERE u.role = :role AND s.filiere = :filiere';
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':role', $role = 'etudiant');
        $stmt->bindParam(':filiere', $filiere);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function afficherMoyenne(database $db): float {
        $sql = 'SELECT AVG(s.note) as moyenne 
                FROM users u 
                JOIN students s ON u.id = s.user_id 
                WHERE u.role = :role';
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':role', $role = 'etudiant');
        $stmt->execute();
        $result = $stmt->fetch();
        return isset($result['moyenne']) ? (float)$result['moyenne'] : 0.0;
    }
}