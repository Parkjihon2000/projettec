<?php
class database{
   private $host='localhost';
   private $dbname='user';
   private $username='root';
   private $pwd='';
   private $pdo;
//    
public function connect():void{
    try{ 
    $this->pdo = new PDO("mysql:host={$this->host};dbname={$this->dbname}", $this->username, $this->pwd);
    $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(Exception $e){
        die("No connection: " . $e->getMessage());
    }
}

}