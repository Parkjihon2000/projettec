<?php
class Utilisateur {
    private string $id; // Changed from int to string
    private string $nom;
    private string $email;
    private string $role;

    public function __construct(string $id, string $nom,string $prenom, string $email, string $role) {
        $this->id = $id;
        $this->nom = $nom;
        $this->email = $email;
        $this->role = $role;
    }

    // Getters
    public function getId(): string { return $this->id; } // Updated to return string
    public function getNom(): string { return $this->nom; }
    public function getEmail(): string { return $this->email; }
    public function getRole(): string { return $this->role; }

    // Setters
    public function setId(string $id): void { $this->id = $id; } // Updated to accept string
    public function setNom(string $nom): void { $this->nom = $nom; }
    public function setEmail(string $email): void { $this->email = $email; }
    public function setRole(string $role): void { $this->role = $role; }

    public function afficherProfil(): void {
        echo "Utilisateur {$this->id} - {$this->nom} - {$this->email} - {$this->role}<br>";
    }

    // Méthode statique pour valider un email
    public static function validerEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}
?>