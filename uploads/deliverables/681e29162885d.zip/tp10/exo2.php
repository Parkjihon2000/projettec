<?php
class user{
    private $id ;
    private $nom;
    private $email;
    private $role;
     // Constructeur
     public function __construct(int $id, string $nom, string $email, string $role) {
        $this->id = $id;
        $this->nom = $nom;
        $this->email = $email;
        $this->role = $role;
    }
    // setters
    public function setId(int $id):void{
        $this->id=$id;

    }
    public function setNom( string $nom):void{
        $this->nom=$nom;

    }
    public function setEmail(string $email):void{
        $this->email=$email;

    }
    public function setRole(string $role):void{
        $this->role=$role;

    }
    public function getId():int{
        return $this->id;
    }
    public function getNom():string{
        return $this->nom;
    }
    public function getEmail():string{
        return $this->email;
    }
    public function getRole():string{
        return $this->role;
    }
    // methods
    public function afficherInfos():void{
        echo "Utilisateur {$this->id} - {$this->nom} - {$this->email} - {$this->role}<br>";
    }
    public static function validerEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }


    
}
// Créez un tableau d’objets Utilisateur contenant 5 utilisateurs
$table=[
    new user(1,"larbi","moha","mohamolzit@gmail.com","enseignant"),
    new user(2,"nadir","nadore","molzri3a@gmail.com","enseignant"),
    new user(3, "Alice Dupont", "alice@ecole.com", "etudiant"),
    new user(4, "Bob Martin", "bob@ecole.com", "etudiant"),
    new Utilisateur(5, "Eva Moreau", "eva@ecole.com", "etudiant")]
// 
function afficherEnseignant(array $table):void{
    foreach($table as $tab){
        if($tab->getRole=="ensaignant"){
            $tab->afficherInfos();
        }
               
    }
} 
//  
function trouverUtilisateurParId(array $utilisateurs, int $id): ?Utilisateur {
    foreach ($utilisateurs as $u) {
        if ($u->getId() === $id) {
            return $u;
        }
    }
    return null;
}